<?php

class Client extends Eloquent
{


}