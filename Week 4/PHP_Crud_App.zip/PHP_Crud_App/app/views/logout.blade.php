@extends('layout')

@section('content')

<p>You've Logged out. <a href="{{ URL::to('/login') }}">Log In?</a></p>


@stop