@extends('layout')

@section('content')

<h2>Thanks for Registering {{ $theEmail }}</h2>

@stop