@extends('layout')

@section('content')

<h1>YOU ARE NOT AUTHORIZED TO ACCESS THIS PAGE!!!</h1>


@stop